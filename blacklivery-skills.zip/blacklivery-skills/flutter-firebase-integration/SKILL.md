---
name: flutter-firebase-integration
description: >
  Blacklivery Firebase integration guide for Flutter. Use before writing any Firebase-related
  code: Firestore queries, Auth flows, Realtime Database, Cloud Functions calls, Storage uploads,
  FCM push notifications, or security rules. Also use when debugging Firebase errors, setting up
  a new Firebase feature, or writing any datasource class. Covers all collections, data models,
  security rules, and safe write patterns for the Blacklivery app.
---

# Blacklivery Firebase Integration

## Project Setup
```bash
# Run once to configure
flutterfire configure --project=blacklivery-prod
# Generates: lib/firebase_options.dart
```

```dart
// main.dart
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await configureDependencies();
  runApp(const BlackliveryApp());
}
```

## Firestore Collection Structure
```
/users/{userId}
  name, email, phone, photoUrl, region (nigeria|chicago),
  walletBalance (int, kobo/cents), promoBalance (int),
  savedAddresses[], referralCode, createdAt, status

/drivers/{driverId}
  name, email, phone, photoUrl, region,
  vehicleClass, vehicleMake, vehicleModel, vehiclePlate, vehicleColor,
  walletBalance (int), pendingBalance (int), totalEarned (int),
  documentsStatus (pending|under_review|approved|rejected),
  documents: { license, vehicleReg, insurance, photos[] },
  rating (double), totalTrips, acceptanceRate, completionRate,
  isOnline (bool), lastLocation: {lat, lng, updatedAt},
  subscriptionActive (bool), createdAt, status

/trips/{tripId}
  riderId, driverId, region,
  status (requested|matched|enRoute|arrived|inProgress|completed|cancelled),
  vehicleClass, pickupAddress, dropoffAddress,
  pickupGeo: {lat, lng}, dropoffGeo: {lat, lng},
  fareBreakdown: { baseFare, distanceFare, timeFare, surgeMultiplier,
                   totalFare, platformCommission, driverEarnings },
  currency (NGN|USD),
  paymentMethod, paymentStatus, paymentRef,
  cancelledBy, cancellationFee, cancellationReason,
  waitTimeStarted, waitTimeMinutes,
  riderRating, driverRating, riderReview, driverReview,
  createdAt, startedAt, completedAt

/deliveries/{deliveryId}
  [same structure as trips + packageType, serviceType, isFragile, extraStops]

/driverLocations/{driverId}          ← Firebase Realtime DB (not Firestore)
  lat, lng, heading, updatedAt, isOnline, vehicleClass, region

/pricing/{region}                    ← region = "nigeria_lagos" | "nigeria_abuja" | "chicago"
  baseFares: {sedan, suv, xl},
  kmRates / mileRates: {sedan, suv, xl},
  minuteRates: {sedan, suv, xl},
  minimumFares: {sedan, suv, xl},
  surgeConfig: {active, multiplier, zones[]},
  cancellationFees: {sedan, suv, xl},
  noShowFees: {sedan, suv, xl},
  waitTimeFreeMinutes, waitTimeRatePerMin

/surgeZones/{zoneId}
  name, region, polygon: [{lat, lng}], active, multiplier, reason, expiresAt

/promotions/{promoId}
  code, discountType (percent|fixed), discountValue,
  maxUses, currentUses, expiresAt, active, region

/disputes/{disputeId}
  tripId, raisedBy (rider|driver), userId, reason,
  status (open|resolved|dismissed), resolution, resolvedBy, createdAt

/adminConfig
  maintenanceMode, minAppVersion, commissionRate, insuranceDeduction

/auditLog/{logId}
  action, performedBy, targetId, before, after, timestamp
```

## Datasource Pattern (only class that touches Firebase)
```dart
@injectable
class TripDatasource {
  final FirebaseFirestore _firestore;
  final FirebaseDatabase _rtdb;
  TripDatasource(this._firestore, this._rtdb);

  Future<TripModel> createTrip(RideRequest request) async {
    final ref = _firestore.collection('trips').doc();
    final data = TripModel.fromRequest(request, id: ref.id).toJson();
    await ref.set(data);
    return TripModel.fromJson({...data, 'id': ref.id});
  }

  Stream<TripModel> watchTrip(String tripId) {
    return _firestore
      .collection('trips')
      .doc(tripId)
      .snapshots()
      .map((snap) => TripModel.fromJson(snap.data()!));
  }

  // Driver real-time location — use Realtime DB not Firestore
  Stream<DriverLocation> watchDriverLocation(String driverId) {
    return _rtdb
      .ref('driverLocations/$driverId')
      .onValue
      .map((event) => DriverLocation.fromJson(
            Map<String, dynamic>.from(event.snapshot.value as Map)));
  }
}
```

## Wallet & Payment Writes — Always Use Transactions
```dart
// NEVER do two separate writes for wallet operations
// ALWAYS use a transaction to prevent race conditions

Future<void> completeTripAndCreditWallet(String tripId, int totalFare) async {
  await _firestore.runTransaction((transaction) async {
    final tripRef = _firestore.collection('trips').doc(tripId);
    final tripSnap = await transaction.get(tripRef);

    final driverId = tripSnap.data()!['driverId'] as String;
    final driverRef = _firestore.collection('drivers').doc(driverId);
    final driverSnap = await transaction.get(driverRef);

    final commission = (totalFare * 0.25).round();
    final driverEarnings = totalFare - commission;
    final currentBalance = driverSnap.data()!['walletBalance'] as int;

    transaction.update(tripRef, {
      'status': 'completed',
      'fareBreakdown.platformCommission': commission,
      'fareBreakdown.driverEarnings': driverEarnings,
      'completedAt': FieldValue.serverTimestamp(),
    });

    transaction.update(driverRef, {
      'walletBalance': currentBalance + driverEarnings,
      'totalTrips': FieldValue.increment(1),
      'totalEarned': FieldValue.increment(driverEarnings),
    });
  });
}
```

## Driver Location Broadcasting (Realtime DB)
```dart
@injectable
class LocationBroadcastService {
  final FirebaseDatabase _rtdb;
  Timer? _timer;

  void startBroadcasting(String driverId) {
    _timer = Timer.periodic(const Duration(seconds: 4), (_) async {
      final position = await Geolocator.getCurrentPosition();
      await _rtdb.ref('driverLocations/$driverId').update({
        'lat': position.latitude,
        'lng': position.longitude,
        'heading': position.heading,
        'updatedAt': ServerValue.timestamp,
        'isOnline': true,
      });
    });
  }

  void stopBroadcasting(String driverId) {
    _timer?.cancel();
    _rtdb.ref('driverLocations/$driverId').update({'isOnline': false});
  }
}
```

## FCM Push Notifications
```dart
@injectable
class NotificationService {
  Future<void> initialize() async {
    await FirebaseMessaging.instance.requestPermission();

    // Foreground messages
    FirebaseMessaging.onMessage.listen((message) {
      // Show local notification
    });

    // Background tap → navigate
    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      final tripId = message.data['tripId'];
      if (tripId != null) router.push('/trip/$tripId');
    });
  }

  Future<String?> getToken() => FirebaseMessaging.instance.getToken();
}
```

## Firestore Security Rules
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Riders: own data only
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
    }

    // Drivers: own data only
    match /drivers/{driverId} {
      allow read, write: if request.auth.uid == driverId;
    }

    // Trips: rider or assigned driver can read; only backend writes
    match /trips/{tripId} {
      allow read: if request.auth.uid == resource.data.riderId
                  || request.auth.uid == resource.data.driverId;
      allow write: if false; // Cloud Functions only
    }

    // Pricing: anyone authenticated can read, only admin writes
    match /pricing/{region} {
      allow read: if request.auth != null;
      allow write: if false; // Admin SDK only
    }

    // Admin: deny all client access
    match /adminConfig/{doc} {
      allow read, write: if false;
    }
  }
}
```

## Cloud Functions — Callable from Flutter
```dart
// Call a Cloud Function
final functions = FirebaseFunctions.instance;

Future<Map<String, dynamic>> verifyPayment(String ref) async {
  final callable = functions.httpsCallable('verifyPaystackPayment');
  final result = await callable.call({'reference': ref});
  return Map<String, dynamic>.from(result.data);
}
```

## Key Rules
1. Realtime DB for driver locations (high-frequency writes)
2. Firestore for everything else (structured data, queries)
3. ALL wallet/payment writes inside runTransaction()
4. Never expose Admin SDK to client apps
5. Store timestamps as FieldValue.serverTimestamp(), not DateTime.now()
6. Store all money as int (kobo/cents), never double
7. Listen to trips with StreamBuilder — never poll
